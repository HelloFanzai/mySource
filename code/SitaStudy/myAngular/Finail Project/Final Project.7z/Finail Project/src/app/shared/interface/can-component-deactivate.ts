export interface CanComponentDeactivate {
    canNavigate: boolean;
}

